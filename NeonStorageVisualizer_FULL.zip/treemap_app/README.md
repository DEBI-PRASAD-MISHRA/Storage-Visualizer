
# Neon Storage Visualizer (Full) - JavaFX

## Summary
Full recursive scan, squarified treemap layout, safe-delete (moves files to app recycle folder), screenshot saving, theme selector.

## How to run (development)
1. Install JDK 17+ and Maven.
2. Unzip project. In project root (where pom.xml is), run:
   mvn javafx:run

## Create native installer (jpackage) - Windows example
1. Install JDK 17+ with jpackage available (OpenJDK with jpackage).
2. Build jar (example):
   mvn clean package
3. Create package (example):
   jpackage --name NeonStorageVisualizer --app-version 1.1.0 --input target --main-jar neon-storage-visualizer-1.1.0.jar --type exe --icon path\to\icon.ico

Adjust paths and options as needed for your environment.

## GitHub push (recommended)
1. git init
2. git add .
3. git commit -m "Initial commit - Neon Storage Visualizer"
4. Create repo on GitHub and push:
   git remote add origin https://github.com/yourusername/neon-storage-visualizer.git
   git branch -M main
   git push -u origin main

## Notes
- Safe-delete moves files to a hidden folder in the user's home directory: ~/.neon_recycle
- Deleting very large folders may fail if permissions are denied; app shows errors in status bar.
