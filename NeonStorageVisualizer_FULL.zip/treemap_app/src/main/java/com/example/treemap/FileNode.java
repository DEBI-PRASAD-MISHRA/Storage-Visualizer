
package com.example.treemap;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FileNode {
    private Path path;
    private String name;
    private long size;
    private List<FileNode> children = new ArrayList<>();

    public FileNode(Path path, String name, long size) {
        this.path = path;
        this.name = name;
        this.size = size;
    }

    public Path getPath() { return path; }
    public String getName() { return name; }
    public long getSize() { return size; }
    public List<FileNode> getChildren() { return children; }
    public void addChild(FileNode c) { children.add(c); }
    public void setSize(long s) { this.size = s; }
}
