
package com.example.treemap;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class FileScanner {

    private static final Map<Path, Long> sizeCache = new ConcurrentHashMap<>();

    public static FileNode scanRoots() throws IOException {
        FileNode root = new FileNode(Paths.get("/"), "Root", 0);
        Iterable<Path> roots = FileSystems.getDefault().getRootDirectories();
        for (Path r : roots) {
            try {
                long sz = folderSize(r);
                FileNode fn = new FileNode(r, r.toString(), sz);
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(r)) {
                    for (Path p : ds) {
                        long s = Files.isDirectory(p) ? folderSize(p) : safeSize(p);
                        fn.addChild(new FileNode(p, p.getFileName()==null?p.toString():p.getFileName().toString(), s));
                    }
                } catch (Exception e) {}
                root.addChild(fn);
            } catch (Exception e) { }
        }
        long total = root.getChildren().stream().mapToLong(FileNode::getSize).sum();
        root.setSize(total);
        return root;
    }

    public static FileNode scan(Path folder) throws IOException {
        FileNode node = new FileNode(folder, folder.getFileName()==null?folder.toString():folder.getFileName().toString(), 0);
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(folder)) {
            for (Path p : ds) {
                try {
                    if (Files.isDirectory(p)) {
                        long size = folderSize(p);
                        FileNode child = new FileNode(p, p.getFileName()==null?p.toString():p.getFileName().toString(), size);
                        node.addChild(child);
                    } else {
                        long size = safeSize(p);
                        node.addChild(new FileNode(p, p.getFileName()==null?p.toString():p.getFileName().toString(), size));
                    }
                } catch (Exception ex) { }
            }
        } catch (Exception e) {}
        long total = node.getChildren().stream().mapToLong(FileNode::getSize).sum();
        node.setSize(total);
        return node;
    }

    public static long folderSize(Path folder) {
        try {
            if (sizeCache.containsKey(folder)) return sizeCache.get(folder);
            final long[] size = {0};
            Files.walkFileTree(folder, new SimpleFileVisitor<Path>() {
                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    size[0] += attrs.size();
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFileFailed(Path file, IOException exc) { return FileVisitResult.CONTINUE; }
            });
            sizeCache.put(folder, size[0]);
            return size[0];
        } catch (Exception e) { return 0; }
    }

    private static long safeSize(Path p) {
        try { return Files.size(p); } catch (Exception e) { return 0; }
    }
}
