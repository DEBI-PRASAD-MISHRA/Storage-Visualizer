
package com.example.treemap;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class Main extends Application {

    private BorderPane rootPane;
    private Pane canvas;
    private Label statusLabel;
    private Deque<Path> history = new ArrayDeque<>();
    private FileNode currentNode;
    private ComboBox<String> themeBox;
    private File recycleDir;

    private Map<String, Theme> themes = new HashMap<>();

    @Override
    public void start(Stage primaryStage) {
        rootPane = new BorderPane();
        rootPane.setStyle("-fx-background-color: #05060a;");

        themes.put("Cyan-Blue", new Theme("#071126", "#00FFEA"));
        themes.put("Purple-Pink", new Theme("#120616", "#FF00D4"));
        themes.put("Green-Lime", new Theme("#061207", "#7CFF00"));

        ToolBar toolbar = new ToolBar();
        Button backBtn = new Button("Back");
        Button refresh = new Button("Refresh");
        Button snap = new Button("Save Screenshot");
        statusLabel = new Label("Ready");
        statusLabel.setTextFill(Color.web("#00FFEA"));

        themeBox = new ComboBox<>();
        themeBox.getItems().addAll("Cyan-Blue", "Purple-Pink", "Green-Lime");
        themeBox.setValue("Cyan-Blue");
        themeBox.setOnAction(e -> applyTheme(themeBox.getValue()));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        toolbar.getItems().addAll(backBtn, refresh, snap, new Separator(), new Label("Theme:"), themeBox, spacer, statusLabel);
        toolbar.setStyle("-fx-background-color: transparent;");

        backBtn.setOnAction(e -> {
            if (!history.isEmpty()) {
                Path prev = history.pop();
                openPath(prev);
            } else openRootView();
        });

        refresh.setOnAction(e -> {
            if (currentNode != null) openPath(currentNode.getPath()); else openRootView();
        });

        snap.setOnAction(e -> saveScreenshot());

        canvas = new Pane();
        canvas.setPadding(new Insets(10));
        canvas.setMinSize(1000, 700);

        ScrollPane sp = new ScrollPane(canvas);
        sp.setFitToWidth(true);
        sp.setFitToHeight(true);
        sp.setStyle("-fx-background: transparent; -fx-border-color: transparent;");

        rootPane.setTop(toolbar);
        rootPane.setCenter(sp);

        Scene scene = new Scene(rootPane, 1200, 800);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Neon Storage Visualizer - Inception View (Squarified)");
        primaryStage.show();

        // create recycle dir in user home
        recycleDir = new File(System.getProperty("user.home"), ".neon_recycle");
        if (!recycleDir.exists()) recycleDir.mkdirs();

        applyTheme("Cyan-Blue");
        openRootView();
    }

    private void applyTheme(String name) {
        Theme t = themes.getOrDefault(name, themes.get("Cyan-Blue"));
        rootPane.setStyle("-fx-background-color: " + t.bg + ";");
        statusLabel.setTextFill(Color.web(t.accent));
    }

    private void openRootView() {
        statusLabel.setText("Scanning roots...");
        canvas.getChildren().clear();
        new Thread(() -> {
            try {
                FileNode roots = FileScanner.scanRoots();
                Platform.runLater(() -> {
                    currentNode = roots;
                    history.clear();
                    squarifyAndRender(roots, 10, 10, canvas.getWidth()-20, canvas.getHeight()-20);
                    statusLabel.setText("Done: Root view");
                });
            } catch (Exception e) {
                Platform.runLater(() -> statusLabel.setText("Scan failed: " + e.getMessage()));
            }
        }).start();
    }

    private void openPath(Path p) {
        statusLabel.setText("Scanning: " + p.toString());
        canvas.getChildren().clear();
        new Thread(() -> {
            try {
                FileNode node = FileScanner.scan(p);
                Platform.runLater(() -> {
                    if (currentNode != null && currentNode.getPath() != null) history.push(currentNode.getPath());
                    currentNode = node;
                    squarifyAndRender(node, 10, 10, canvas.getWidth()-20, canvas.getHeight()-20);
                    statusLabel.setText("Showing: " + p.toString());
                });
            } catch (Exception e) {
                Platform.runLater(() -> statusLabel.setText("Scan failed: " + e.getMessage()));
            }
        }).start();
    }

    // Squarified treemap implementation (simple)
    private void squarifyAndRender(FileNode node, double x, double y, double w, double h) {
        canvas.getChildren().clear();
        List<FileNode> children = new ArrayList<>(node.getChildren());
        children.sort((a,b) -> Long.compare(b.getSize(), a.getSize())); // descending
        squarify(children, new ArrayList<>(), w, x, y, w, h);
    }

    private void squarify(List<FileNode> children, List<FileNode> row, double containerSize, double x, double y, double w, double h) {
        if (children.isEmpty()) {
            layoutRow(row, x, y, w, h);
            return;
        }
        FileNode c = children.get(0);
        List<FileNode> newRow = new ArrayList<>(row);
        newRow.add(c);
        double aspectBefore = worstAspect(row, containerSize, w, h);
        double aspectAfter = worstAspect(newRow, containerSize, w, h);
        if (row.isEmpty() || aspectAfter <= aspectBefore) {
            children.remove(0);
            squarify(children, newRow, containerSize, x, y, w, h);
        } else {
            // layout current row and continue
            double used = totalSize(row);
            double total = totalSize(row) + totalSize(children);
            double area = (used / (used + total)) * (w * h);
            double rowWidth = (w * used) / (used + total); // approximate split
            layoutRow(row, x, y, rowWidth, h);
            // remaining area
            double nx = x + rowWidth;
            double nw = w - rowWidth;
            squarify(children, new ArrayList<>(), nw, nx, y, nw, h);
        }
    }

    private void layoutRow(List<FileNode> row, double x, double y, double w, double h) {
        double total = totalSize(row);
        if (total <= 0) total = 1;
        double offset = 0;
        boolean horizontal = w >= h;
        for (FileNode fn : row) {
            double ratio = fn.getSize() / total;
            double rw = horizontal ? w : w * ratio;
            double rh = horizontal ? h * ratio : h;
            double rx = x + (horizontal ? offset : 0);
            double ry = y + (horizontal ? 0 : offset);
            if (rw < 3) rw = 3;
            if (rh < 3) rh = 3;
            Rectangle rect = makeRect(rx, ry, rw, rh, fn);
            canvas.getChildren().add(rect);
            if (rw > 120 && rh > 40) {
                Text txt = new Text(fn.getName());
                txt.setFill(Color.web(getAccent()));
                txt.setX(rx + 6);
                txt.setY(ry + 18);
                canvas.getChildren().add(txt);
            }
            offset += (horizontal ? rw : rh);
        }
    }

    private double totalSize(List<FileNode> list) {
        return list.stream().mapToDouble(FileNode::getSize).sum();
    }

    private double worstAspect(List<FileNode> row, double containerSize, double w, double h) {
        if (row.isEmpty()) return Double.MAX_VALUE;
        double total = totalSize(row);
        double max = row.stream().mapToDouble(FileNode::getSize).max().orElse(1);
        double min = row.stream().mapToDouble(FileNode::getSize).min().orElse(1);
        double area = (total / containerSize) * (w*h);
        double sq = (area * area);
        double aspect1 = (sq * max) / ((total*total) * (w*h));
        double aspect2 = ((total*total) * (w*h)) / (sq * min);
        return Math.max(aspect1, aspect2);
    }

    private Rectangle makeRect(double x, double y, double w, double h, FileNode node) {
        Rectangle r = new Rectangle(x, y, w, h);
        r.setArcWidth(8);
        r.setArcHeight(8);
        r.setFill(Color.web("#071126"));
        r.setStroke(Color.web(getAccent(), 0.7));
        r.setStrokeWidth(1.5);

        Tooltip t = new Tooltip(node.getName() + "\n" + humanReadableByteCount(node.getSize()) + "\nPath: " + node.getPath().toString());
        Tooltip.install(r, t);

        r.setOnMouseClicked(ev -> {
            if (ev.getButton() == MouseButton.PRIMARY && ev.getClickCount() == 2) {
                try { Desktop.getDesktop().open(node.getPath().toFile()); } catch (Exception e) { statusLabel.setText("Open failed"); }
            } else if (ev.getButton() == MouseButton.PRIMARY && ev.getClickCount() == 1) {
                if (node.getSize() > 0 && !node.getChildren().isEmpty()) openPath(node.getPath());
            } else if (ev.getButton() == MouseButton.SECONDARY) {
                ContextMenu cm = new ContextMenu();
                MenuItem open = new MenuItem("Open");
                MenuItem delete = new MenuItem("Safe Delete (to app recycle)");
                MenuItem info = new MenuItem("Show Info");
                open.setOnAction(ae -> { try { Desktop.getDesktop().open(node.getPath().toFile()); } catch (Exception ex) { statusLabel.setText("Open failed"); } });
                delete.setOnAction(ae -> {
                    Alert al = new Alert(Alert.AlertType.CONFIRMATION, "Move " + node.getName() + " to app recycle?", ButtonType.YES, ButtonType.NO);
                    al.showAndWait().ifPresent(bt -> {
                        if (bt == ButtonType.YES) {
                            try {
                                Path src = node.getPath();
                                File target = new File(recycleDir, src.getFileName().toString() + "_" + System.currentTimeMillis());
                                src.toFile().renameTo(target);
                                statusLabel.setText("Moved to app recycle: " + target.getName());
                                openRootView();
                            } catch (Exception ex) { statusLabel.setText("Safe delete failed: " + ex.getMessage()); }
                        }
                    });
                });
                info.setOnAction(ae -> {
                    Alert a = new Alert(Alert.AlertType.INFORMATION);
                    a.setHeaderText(node.getName());
                    a.setContentText("Path: " + node.getPath().toString() + "\nSize: " + humanReadableByteCount(node.getSize()));
                    a.showAndWait();
                });
                cm.getItems().addAll(open, delete, info);
                cm.show(r, ev.getScreenX(), ev.getScreenY());
            }
        });
        return r;
    }

    private void saveScreenshot() {
        try {
            WritableImage wi = canvas.snapshot(new SnapshotParameters(), null);
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
            String fname = "neon_snapshot_" + LocalDateTime.now().format(df) + ".png";
            File out = new File(System.getProperty("user.home"), fname);
            ImageIO.write(SwingFXUtils.fromFXImage(wi, null), "png", out);
            statusLabel.setText("Screenshot saved: " + out.getAbsolutePath());
        } catch (Exception e) {
            statusLabel.setText("Screenshot failed: " + e.getMessage());
        }
    }

    private String getAccent() {
        Theme t = themes.getOrDefault(themeBox.getValue(), themes.get("Cyan-Blue"));
        return t.accent;
    }

    private static String humanReadableByteCount(long bytes) {
        int unit = 1024;
        if (bytes < unit) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(unit));
        String pre = ("KMGTPE").charAt(exp-1) + "";
        return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);
    }

    public static void main(String[] args) {
        launch(args);
    }

    private static class Theme {
        String bg, accent;
        Theme(String bg, String accent) { this.bg = bg; this.accent = accent; }
    }
}
